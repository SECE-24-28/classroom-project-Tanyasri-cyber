// -------------------- IMPORTS --------------------
const express = require("express")
const mongoose = require("mongoose")
const cors = require("cors")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const helmet = require("helmet")
const rateLimit = require("express-rate-limit")
require("dotenv").config()

const PORT = process.env.PORT

// -------------------- APP INIT --------------------
const app = express()
app.use(express.json())
app.use(cors())
app.use(helmet())

// -------------------- RATE LIMIT --------------------
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100
  })
)

// -------------------- DATABASE --------------------
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err))

// -------------------- SCHEMAS --------------------
const User = mongoose.model(
  "User",
  new mongoose.Schema({
    username: String,
    email: String,
    password: String,
    otp: Number
  })
)

const Category = mongoose.model(
  "Category",
  new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    description: String,
    createdAt: { type: Date, default: Date.now }
  })
)

const Product = mongoose.model(
  "Product",
  new mongoose.Schema({
    title: String,
    price: Number,
    image: String
  })
)

// -------------------- MIDDLEWARES --------------------
const validateSignup = (req, res, next) => {
  const { username, email, password } = req.body

  if (!/^[a-zA-Z0-9]{3,}$/.test(username))
    return res.status(400).json({ message: "Invalid username" })

  if (!/^\S+@\S+\.\S+$/.test(email))
    return res.status(400).json({ message: "Invalid email" })

  if (!/(?=.*\d).{8,}/.test(password))
    return res.status(400).json({ message: "Weak password" })

  next()
}

const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1]
  if (!token) return res.status(401).json({ message: "Token missing" })

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(401).json({ message: "Invalid token" })
    req.user = user
    next()
  })
}

// -------------------- AUTH ROUTES --------------------
app.post("/signup", validateSignup, async (req, res) => {
  const password = await bcrypt.hash(req.body.password, 10)
  await new User({ ...req.body, password }).save()
  res.status(201).json({ message: "User registered" })
})

app.post("/signin", async (req, res) => {
  const user = await User.findOne({ email: req.body.email })
  if (!user) return res.status(404).json({ message: "User not found" })

  const match = await bcrypt.compare(req.body.password, user.password)
  if (!match) return res.status(401).json({ message: "Wrong password" })

  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET)
  res.json({ token, user })
})

app.post("/forgot-password", async (req, res) => {
  const user = await User.findOne({ email: req.body.email })
  if (!user) return res.status(404).json({ message: "User not found" })

  user.otp = Math.floor(100000 + Math.random() * 900000)
  await user.save()

  res.json({ message: "OTP generated", otp: user.otp })
})

app.post("/reset-password", async (req, res) => {
  const user = await User.findOne({
    email: req.body.email,
    otp: req.body.otp
  })

  if (!user) return res.status(400).json({ message: "Invalid OTP" })

  user.password = await bcrypt.hash(req.body.newPassword, 10)
  user.otp = null
  await user.save()

  res.json({ message: "Password reset successful" })
})

// -------------------- CATEGORY ROUTES --------------------
app.post("/categories", async (req, res) => {
  res.status(201).json(await new Category(req.body).save())
})

app.get("/categories", async (_, res) => {
  res.json(await Category.find())
})

app.get("/categories/:id", async (req, res) => {
  res.json(await Category.findById(req.params.id))
})

app.put("/categories/:id", async (req, res) => {
  res.json(
    await Category.findByIdAndUpdate(req.params.id, req.body, { new: true })
  )
})

app.delete("/categories/:id", async (req, res) => {
  await Category.findByIdAndDelete(req.params.id)
  res.json({ message: "Category deleted" })
})

// -------------------- PRODUCT ROUTES --------------------
app.get("/products", async (req, res) => {
  const page = Number(req.query.page) || 1
  const limit = Number(req.query.limit) || 10

  const products = await Product.find()
    .skip((page - 1) * limit)
    .limit(limit)

  const total = await Product.countDocuments()

  res.json({
    products,
    currentPage: page,
    totalPages: Math.ceil(total / limit),
    totalProducts: total
  })
})

app.get("/products/search", async (req, res) => {
  const { query, minPrice, maxPrice } = req.query
  const filter = {}

  if (query) filter.title = { $regex: query, $options: "i" }
  if (minPrice && maxPrice)
    filter.price = { $gte: minPrice, $lte: maxPrice }

  res.json(await Product.find(filter))
})

app.delete("/deleteproduct/:id", authenticateToken, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id)
  res.json({ message: "Product deleted" })
})

// -------------------- ERROR HANDLER --------------------
app.use((err, req, res, next) => {
  console.error(new Date(), err.message)
  res.status(500).json({ message: "Server error" })
})

// -------------------- SERVER --------------------
app.listen(PORT, () =>
  console.log(`Server running on port ${PORT}`)
)
