import { Link } from "react-router-dom"
import { useAuth } from "../context/AuthContext"

function Header() {
  const { user, logout } = useAuth()

  return (
    <div style={{
      display: "flex",
      justifyContent: "space-between",
      padding: "15px 40px",
      background: "#f5f5f5",
      alignItems: "center"
    }}>
      <h3>E-Commerce</h3>

      <div style={{ display: "flex", gap: "15px", alignItems: "center" }}>
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>

        {user ? (
          <>
            <Link to="/products">Products</Link>
            <Link to="/add-product">Add Product</Link>
            <span><b>{user.username}</b></span>
            <button onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/signin">Signin</Link>
            <Link to="/signup">Signup</Link>
          </>
        )}
      </div>
    </div>
  )
}

export default Header
