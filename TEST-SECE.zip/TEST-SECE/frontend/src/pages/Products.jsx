import { useEffect, useState } from "react"
import axios from "axios"

function Products() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    axios.get("http://localhost:5000/products")
      .then(res => setProducts(res.data.products))
  }, [])

  return (
    <div style={{ maxWidth: "600px", margin: "40px auto" }}>
      <h2 style={{ textAlign: "center" }}>Products</h2>

      {products.map(p => (
        <div key={p._id} style={{
          padding: "10px",
          border: "1px solid #ddd",
          marginBottom: "10px",
          borderRadius: "6px"
        }}>
          <b>{p.title}</b>
          <p>Price: ₹{p.price}</p>
        </div>
      ))}
    </div>
  )
}

export default Products
