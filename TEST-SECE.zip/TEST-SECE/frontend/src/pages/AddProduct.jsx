import { useState } from "react"
import axios from "axios"

function AddProduct() {
  const [title, setTitle] = useState("")
  const [price, setPrice] = useState("")
  const [image, setImage] = useState("")
  const [msg, setMsg] = useState("")

  const submit = async (e) => {
    e.preventDefault()

    if (!title || price <= 0 || !image) {
      setMsg("Invalid input")
      return
    }

    await axios.post("http://localhost:5000/products", { title, price, image })

    setMsg("Product added successfully")
    setTitle("")
    setPrice("")
    setImage("")
  }

  return (
    <form onSubmit={submit} style={{
      maxWidth: "400px",
      margin: "60px auto",
      padding: "20px",
      border: "1px solid #ccc",
      borderRadius: "8px"
    }}>
      <h2 style={{ textAlign: "center" }}>Add Product</h2>

      <input placeholder="Title"
        value={title}
        onChange={e => setTitle(e.target.value)}
        style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
      />

      <input placeholder="Price"
        value={price}
        onChange={e => setPrice(e.target.value)}
        style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
      />

      <input placeholder="Image URL"
        value={image}
        onChange={e => setImage(e.target.value)}
        style={{ width: "100%", padding: "8px", marginBottom: "15px" }}
      />

      <button style={{ width: "100%", padding: "8px" }}>
        Add Product
      </button>

      <p style={{ textAlign: "center", marginTop: "10px" }}>{msg}</p>
    </form>
  )
}

export default AddProduct
