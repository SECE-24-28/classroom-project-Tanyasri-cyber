import { useState } from "react"
import axios from "axios"

function Signup() {
  const [form, setForm] = useState({})

  const submit = async (e) => {
    e.preventDefault()
    await axios.post("http://localhost:5000/signup", form)
    alert("Signup successful")
  }

  return (
    <form onSubmit={submit} style={{
      maxWidth: "400px",
      margin: "60px auto",
      padding: "20px",
      border: "1px solid #ccc",
      borderRadius: "8px"
    }}>
      <h2 style={{ textAlign: "center" }}>Sign Up</h2>

      <input placeholder="Username"
        onChange={e => setForm({ ...form, username: e.target.value })}
        style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
      />

      <input placeholder="Email"
        onChange={e => setForm({ ...form, email: e.target.value })}
        style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
      />

      <input type="password" placeholder="Password"
        onChange={e => setForm({ ...form, password: e.target.value })}
        style={{ width: "100%", padding: "8px", marginBottom: "15px" }}
      />

      <button style={{ width: "100%", padding: "8px" }}>
        Sign Up
      </button>
    </form>
  )
}

export default Signup
