import { useState } from "react"
import axios from "axios"
import { useAuth } from "../context/AuthContext"

function Signin() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const { login } = useAuth()

  const submit = async (e) => {
    e.preventDefault()
    const res = await axios.post("http://localhost:5000/signin", { email, password })
    login(res.data.user, res.data.token)
  }

  return (
    <form onSubmit={submit} style={{
      maxWidth: "400px",
      margin: "60px auto",
      padding: "20px",
      border: "1px solid #ccc",
      borderRadius: "8px"
    }}>
      <h2 style={{ textAlign: "center" }}>Sign In</h2>

      <input
        placeholder="Email"
        onChange={e => setEmail(e.target.value)}
        style={{ width: "100%", padding: "8px", marginBottom: "10px" }}
      />

      <input
        type="password"
        placeholder="Password"
        onChange={e => setPassword(e.target.value)}
        style={{ width: "100%", padding: "8px", marginBottom: "15px" }}
      />

      <button style={{ width: "100%", padding: "8px" }}>
        Sign In
      </button>
    </form>
  )
}

export default Signin
