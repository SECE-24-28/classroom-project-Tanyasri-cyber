function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "80px" }}>
      <h1>Welcome to E-Commerce App</h1>
      <p>Simple & Secure Online Shopping</p>
    </div>
  )
}

export default Home
