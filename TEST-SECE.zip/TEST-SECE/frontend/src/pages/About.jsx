function About() {
  return (
    <div style={{ maxWidth: "600px", margin: "60px auto", textAlign: "center" }}>
      <h2>About Us</h2>
      <p>
        This is a MERN stack e-commerce application built for learning and assessment purposes.
      </p>
    </div>
  )
}

export default About
