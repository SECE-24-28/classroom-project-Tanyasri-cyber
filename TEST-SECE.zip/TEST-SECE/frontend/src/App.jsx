import { Routes, Route } from "react-router-dom"
import Header from "./components/Header"
import ProtectedRoute from "./components/ProtectedRoute"

import Home from "./pages/Home"
import About from "./pages/About"
import Products from "./pages/Products"
import AddProduct from "./pages/AddProduct"
import Signin from "./pages/Signin"
import Signup from "./pages/Signup"

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/signup" element={<Signup />} />

        <Route
          path="/products"
          element={
            <ProtectedRoute>
              <Products />
            </ProtectedRoute>
          }
        />

        <Route
          path="/add-product"
          element={
            <ProtectedRoute>
              <AddProduct />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  )
}

export default App
